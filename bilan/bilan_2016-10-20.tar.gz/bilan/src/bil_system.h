/**
 * @file
 * - system class
 */

#ifndef BIL_SYSTEM_H_INCLUDED
#define BIL_SYSTEM_H_INCLUDED

#include "bil_model.h"

class bil_system;

/**
 * - functoid class for access to methods when optimizing
 */
class bilsys_fcd
{
  public:
    bilsys_fcd() { psbil = 0; };
    //! creation of functoid for a system
    explicit bilsys_fcd(bil_system *sbil) { psbil = sbil; };
    //! sets pointer to system
    void set(bil_system *sbil) { psbil = sbil; };
    void calc_sum_weights(); //!< calculates sum of weights for optimization
    void check_vars_for_optim(bool is_weight_BF); //!< checks availability of variables for optimization
    double get_param(unsigned par_n, optimizer_gen<bilsys_fcd*>::param_type par_type); //!< gets value of parameter
    void set_param(unsigned par_n, optimizer_gen<bilsys_fcd*>::param_type par_type, double value); //!< sets value of parameter
    unsigned get_param_count(); //!< gets number of parameters
    unsigned get_param_fix_count(); //!< gets number of fixed parameters
    unsigned get_catch_count(); //!< gets number of catchments
    std::string get_param_name(unsigned par_n); //!< gets name of parameter
    void run(long double init_GS); //!< runs the model
    long double calc_crit(unsigned crit, unsigned pen, double weight_BF, bool use_weights); //!< calculates optimization criterion value

  private:
    bil_system* psbil; //!< pointer to a system
};

/**
 * - system of catchments
 */
class bil_system
{
  public:
    bil_system();
    bil_system(const bil_system& orig);
    ~bil_system();
    void assign_id(unsigned cat_n); //!< assigns an ID to the catchment being added
    void set_larger_id(unsigned curr_pos, unsigned larger_pos); //!< sets larger ID by positions
    void set_larger_id(unsigned curr_pos, std::string larger_id); //!< sets larger ID by position and ID
    std::string find_top_id(bilan *bil, std::list<std::string> &found_ids); //!< finds top catchment within the system
    void add_catchment(bilan *bil); //!< adds a Bilan instance to the system to the end
    void add_catchment(bilan *bil, unsigned cat_n, bool clear_opt); //!< adds a Bilan instance to the given position
    void remove_catchment(unsigned cat_n); //!< removes a model from the system
    unsigned get_catch_count(bool only_opt); //!< gets number of catchments
    bilan get_catch(unsigned cat_n); //!< gets catchment
    bilan* get_pcatch(unsigned cat_n); //!< gets pointer to catchment
    bilan* get_pcatch_by_id(std::string cat_id); //!< gets pointer to catchment by its ID
    int get_pos_by_id(std::string cat_id); //!< gets position in the system by catchment ID
    void set_catch(unsigned cat_n, bilan *bil); //!< sets catchment
    bilan get_catch_opt(unsigned cat_n); //!< gets optimized catchment
    bilan* get_pcatch_opt(unsigned cat_n); //!< gets pointer to optimized catchment
    void change_optim_type(optimizer_gen<bilsys_fcd*>::optim_type new_type); //!< changes type of optimization
    void calc_pet(); //!< calculates PET estimation for all catchments (now only by tabular method)
    void prepare_opt(); //!< prepares optimization
    void optimize(); //!< runs optimization for the system
    void calc_sum_weights(); //!< calculates sum of weights for catchments to be optimized
    void check_vars_for_optim(bool is_weight_BF); //!< checks availability of variables for optimization
    double get_param(unsigned par_n, optimizer_gen<bilsys_fcd*>::param_type par_type); //!< gets parameter value
    void set_param(unsigned par_n, optimizer_gen<bilsys_fcd*>::param_type par_type, double value); //!< sets parameter value
    unsigned get_common_ts(unsigned cat_opt_n); //!< gets number of common time steps
    //! gets optimization criterion value for the system
    long double get_optim_ok() { return optim->get_ok(); };
    //! gets type of optimization criterion for the system
    unsigned get_optim_crit_type() { return optim->crit_type; };
    unsigned get_param_count(); //!< gets number of all parameters
    unsigned get_param_fix_count(); //!< gets number of fixed parameters
    std::string get_param_name(unsigned par_n); //!< gets parameter name
    void run(long double init_GS); //!< runs model for all catchments
    long double calc_penalty(unsigned cat_opt_n, unsigned pen); //!< calculates penalty for given optimized catchment
    long double calc_crit(unsigned crit, unsigned pen, double weight_BF, bool use_weights); //!< mean criterion for catchments

    bilsys_fcd fcd; //!< functoid to be used in optimization
    optimizer_gen<bilsys_fcd*> *optim; //!< optimization settings and variables (gradient or DE method)

  private:
    void finish_adding(unsigned pos, bool clear_opt); //!< auxiliary when adding a catchment
    string find_larger_id_optim(string cat_id); //!< gets larger ID from only optimized catchments

    unsigned catch_count; //!< number of catchments
    unsigned catch_opt_count; //!< number of catchments used for optimization
    std::list<bilan> catchs; //!< catchments as Bilan instances
    std::vector<bilan*> catchs_opt; //!< catchments used for optimization
    std::map<std::string, unsigned> common_ts; //!< number of common time steps between catchment and its larger catchment, a key is ID of the smaller catchment
    unsigned common_ts_sum; //!< sum of common time steps
    std::map<std::string, unsigned> common_begin; //!< number of the first common time step for catchment (number related to it) and its larger catchment, a key is ID of the smaller catchment
    std::map<std::string, unsigned> common_begin_larger; //!< number of the first common time step for the larger catchment
    unsigned par_count_catch; //!< number of parameters for one catchment
    unsigned par_fix_count_catch; //!< number of fixed parameters for one catchment
    string next_id; //!< ID within the system to be assigned to the next catchment which will be added
    static const unsigned id_length = 5; //!< length of ID string

};

#endif // BIL_SYSTEM_H_INCLUDED
