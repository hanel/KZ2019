#ifndef BIL_MODIF_H_INCLUDED
#define BIL_MODIF_H_INCLUDED

#include "bil_model.h"

/**
 * - variables for optimization criterion
 */
class crit_vars
{
  public:
    crit_vars() { weight = 1; var_obs = bilan::R; var_mod = bilan::RM; crit = OPTIM; value_obs = -999;};
    enum crit_type {OPTIM, MEAN, SD, RANGE, CUSTOM}; //!< criterion types
    double weight; //!< weight for variable pair
    unsigned var_obs; //!< observed variable
    unsigned var_mod; //!< modelled variable
    unsigned crit; //!< criterion type
    double value_obs; //!< value for observed variable used to calculate criterion (if possible to calculate in advance)
};

/**
 * - Bilan model with modified structure
 */
class bilan_modif : public bilan
{
  public:
    bilan_modif(bilan_type type, unsigned modif_types); //!< sets modification types
    bilan_modif(bilan_type type, unsigned modif_types, unsigned period); //!< sets modification types and period
    bilan_modif(const bilan_modif& orig);
    virtual bilan& operator=(const bilan& orig);
    //! defines variables and other information for optimization criterion
    virtual void set_var_crit(
      const std::vector<double> &weights, const std::vector<unsigned> &vars_obs, const std::vector<unsigned> &vars_mod,
      const std::vector<unsigned> &crits, const std::vector<double> &values_obs);
    virtual double calc_var_char(unsigned pos, bool is_observed); //!< calculates characteristics of given variable
    crit_vars& get_crit_vars(unsigned pos) { return crit_vars_vec[pos]; } //!< criterion for variables getter

    //! type of modification
    enum modification_type {NONE = 0, SOC_ONLY = (1u << 0), PERIOD = (1u << 1), VAR_CRIT = (1u << 2)};

  private:
    virtual void increase_calendar(date &tmp_date); //!< increases given date
    virtual void get_doy_range(unsigned &begin_doy, unsigned &end_doy); //!< gets range for PET calculation
    virtual void recalc_pet_from_months(); //!< recalculates monthly PET values for period
    virtual double get_divide_coeff(int mode); //!< only one coefficient for all modes
    virtual long double calc_crit_RM_BF(unsigned crit_type, double weight_BF, bool use_weights); //!< calculates optimization criterion

    bool is_modif_type(unsigned mtype) { return ((modif_type & mtype) != 0); } //!< checks if a given type is in bitmask

    unsigned modif_type; //!< modification for the model (unsigned because bitwise operations applied)
    unsigned period; //!< length of time step (in days) used instead of monthly or daily
    vector<crit_vars> crit_vars_vec;
};

#endif // BIL_MODIF_H_INCLUDED
