#include "bil_modif.h"

using namespace std;

/**
 * - creates a model with given modifications
 * @param type daily or monthly time step version
 * @param modif_types result of bitwise OR for required modifications
 */
bilan_modif::bilan_modif(bilan_type type, unsigned modif_types) : bilan(type)
{
  modif_type = modif_types;
  period = 0;
  if (is_modif_type(PERIOD))
    throw bil_err("Model cannot be created because period length is not set.");
}

/**
 * - creates an empty model instance of given type and modification type Soc only
 * @param type daily or monthly time step version
 * @param modif_types result of bitwise OR for required modifications
 * @param period length of time step (in days) used instead of monthly or daily
 */
bilan_modif::bilan_modif(bilan_type type, unsigned modif_types, unsigned period) : bilan(type)
{
  modif_type = modif_types;
  this->period = period;
}

/**
 * - assignment operator
 */
bilan& bilan_modif::operator=(const bilan& orig)
{
  if (this != &orig) {
    bilan::operator=(orig);
    const bilan_modif& tmp_orig = dynamic_cast<const bilan_modif&>(orig);
    modif_type = tmp_orig.modif_type;
    period = tmp_orig.period;
  }
  return *this;
}

/**
 * - copy constructor
 */
bilan_modif::bilan_modif(const bilan_modif& orig) : bilan(orig)
{
  modif_type = orig.modif_type;
  period = orig.period;
}

/**
 * - increases given date according to model time step
 * @param tmp_date date whose value will be increased
 */
void bilan_modif::increase_calendar(date &tmp_date)
{
  if (is_modif_type(PERIOD)) {
    for (unsigned d = 0; d < period; d++)
     tmp_date.increase(date::DAY, calen_prop);
  }
  else
    bilan::increase_calendar(tmp_date);
}

/**
 * - gets begin and end for PET calculation
 * @param begin_doy begin of the interval
 * @param end_doy end of the interval
 */
void bilan_modif::get_doy_range(unsigned &begin_doy, unsigned &end_doy)
{
  if (is_modif_type(PERIOD)) {
    begin_doy = calen[ts].get_day_of_year(calen_prop);
    end_doy = begin_doy - 1 + period;
    //end_doy > days_in_year allowed because of periodic functions, only neglecting possible difference in number of days in years
  }
  else
    bilan::get_doy_range(begin_doy, end_doy);
}

/**
 * - recalculates values of PET from months to days (or keeps it for monthly time step)
 * - for vegetation zone method only since empirical tables contain monthly values
 */
void bilan_modif::recalc_pet_from_months()
{
  if (is_modif_type(PERIOD)) {
    for (ts = 0; ts < time_steps; ts++)
      var[ts][PET] = var[ts][PET] * period / 30;
  }
  else
    bilan::recalc_pet_from_months();
}

/**
 * - gets Soc or Socd parameter according to the model time step
 * @param mode model mode based on season
 * @return parameter value
 */
double bilan_modif::get_divide_coeff(int mode)
{
  if (is_modif_type(SOC_ONLY)) {
    int tmp_par;
    if (type == DAILY) {
        if (mode == ZIMNI)
          throw bil_err("No dividing coefficient for the given mode.");
        else
          tmp_par = Socd;
    }
    else
      tmp_par = Soc;
    return param[tmp_par].value;
  }
  else
    return bilan::get_divide_coeff(mode);
}

/**
 * - calculates a characteristics of time series of given variable
 * @param pos index in crit_vars_vec to get variable and type of characteristics
 * @param is_observed whether the observed or modelled variable will be used
 * @return characteristics value
 */
double bilan_modif::calc_var_char(unsigned pos, bool is_observed) {
  unsigned variable;
  if (is_observed)
    variable = crit_vars_vec[pos].var_obs;
  else
    variable = crit_vars_vec[pos].var_mod;
  unsigned char_type = crit_vars_vec[pos].crit;
  long double mean = 0, resul_char = 0;
  if (char_type == crit_vars::MEAN || char_type == crit_vars::SD) {
    for (ts = 0; ts < time_steps; ts++) {
      mean += var[ts][variable];
    }
    mean /= time_steps;
  }
  switch (char_type) {
    case crit_vars::OPTIM:
      break;
    case crit_vars::MEAN:
      resul_char = mean;
      break;
    case crit_vars::SD: {
        for (ts = 0; ts < time_steps; ts++) {
          resul_char += pow(var[ts][variable] - mean, 2);
        }
        resul_char = pow(resul_char / (time_steps - 1), 0.5);
      }
      break;
    case crit_vars::RANGE: {
        long double min_value = 1e6, max_value = -1e6;
        for (ts = 0; ts < time_steps; ts++) {
          if (var[ts][variable] < min_value)
            min_value = var[ts][variable];
          else if (var[ts][variable] > max_value)
            max_value = var[ts][variable];
        }
        resul_char = max_value - min_value;
      }
      break;
    default:
      break;
  }
  return resul_char;
}

/**
 * - calculates optimization criterion for given variables
 * - NS and LNNS are residuals to 1 (to be minimized)
 * @param crit_type type of optimization criterion
 * @param weight_BF weight for baseflow
 * @param use_weights whether to use weights for time steps of runoff
 * @return value of the criterion
 */
long double bilan_modif::calc_crit_RM_BF(unsigned crit_type, double weight_BF, bool use_weights)
{
  if (is_modif_type(VAR_CRIT)) {
    if (crit_vars_vec.size() == 0)
      throw bil_err("No variables for criterion provided.");

    long double ok = 0;
    for (unsigned v = 0; v < crit_vars_vec.size(); v++) {
      //calculate characteristics for observed variable if not provided
      if (crit_vars_vec[v].crit != crit_vars::OPTIM && crit_vars_vec[v].value_obs < -900) {
        crit_vars_vec[v].value_obs = calc_var_char(v, true);
      }
      double value_mod = calc_var_char(v, false);
      if (crit_vars_vec[v].crit == crit_vars::OPTIM)
        ok += crit_vars_vec[v].weight * calc_crit(crit_type, crit_vars_vec[v].var_obs, crit_vars_vec[v].var_mod, use_weights);
      else
        ok += crit_vars_vec[v].weight * abs(crit_vars_vec[v].value_obs - value_mod);
    }
    return ok;
  }
  else
    return bilan::calc_crit_RM_BF(crit_type, weight_BF, use_weights);
}

/**
 * - defines variables for optimization criterion
 * - values_obs are calculated from vars_obs data if not given
 * @param weights weights for variable pairs (does not need to sum up to 1)
 * @param vars_obs observed variables
 * @param vars_mod corresponding modelled variables
 * @param crits criterions used for optimization
 * @param values_obs single values of observed variables used for optimization criterion (if applicable)
 */
void bilan_modif::set_var_crit(
  const vector<double> &weights, const vector<unsigned> &vars_obs, const vector<unsigned> &vars_mod,
  const vector<unsigned> &crits, const vector<double> &values_obs)
{
  if (vars_obs.size() != vars_mod.size())
    throw bil_err("Number of observed and modelled variables for criterion differs.");
  if (weights.size() != vars_mod.size())
    throw bil_err("Number of weights and variables for criterion differs.");
  if (crits.size() != vars_mod.size())
    throw bil_err("Number of criterions and variables for them differs.");
  if (crits.size() != values_obs.size())
    throw bil_err("Number of observed values and variables for them differs.");

  double weights_sum = 0;
  for (unsigned v = 0; v < weights.size(); v++) {
    weights_sum += weights[v];
  }
  crit_vars_vec.resize(weights.size());
  for (unsigned v = 0; v < weights.size(); v++) {
    crit_vars_vec[v].weight = weights[v] / weights_sum;
    crit_vars_vec[v].var_obs = vars_obs[v];
    crit_vars_vec[v].var_mod = vars_mod[v];
    crit_vars_vec[v].crit = crits[v];
    crit_vars_vec[v].value_obs = values_obs[v];
  }
}
