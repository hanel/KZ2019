#include "bil_system.h"

using namespace std;

/**
 * - creates catchment system instance
 */
bil_system::bil_system()
{
  catch_count = 0;
  catch_opt_count = 0;
  par_count_catch = 0;
  par_fix_count_catch = 0;
  string tmp_id(id_length, 'a');
  next_id = tmp_id;
  fcd.set(this);
  optim = new optimizer<bilsys_fcd*>(); //default optimization
  optim->set_functoid(&fcd);
}

/**
 * - copy constructor for the system
 */
bil_system::bil_system(const bil_system& orig)
{
  optim = orig.optim->clone();

  catch_count = orig.catch_count;
  catch_opt_count = orig.catch_opt_count;
  par_count_catch = orig.par_count_catch;
  par_fix_count_catch = orig.par_fix_count_catch;
  next_id = orig.next_id;
  fcd.set(this);
}

bil_system::~bil_system()
{
  delete optim;
}

/**
 * - assing an ID to the catchment at given position and increment next ID
 * - to be used after adding a catchment to the system
 * - as new model instance is created when adding, catchment cannot be used in more systems
 * @param cat_n catchment position
 */
void bil_system::assign_id(unsigned cat_n)
{
  get_pcatch(cat_n)->set_id(next_id);

  for (unsigned pos = 0; pos < id_length; pos++) {
    if (next_id[pos] != 'z') {
        next_id[pos] = next_id[pos] + 1;
        for (unsigned tmp = 0; tmp < pos; tmp++)
          next_id[tmp] = 'a';
        break;
    }
    if (pos == id_length - 1)
      throw bil_err("Out of IDs.");
  }
}

/**
 * - sets ID of larger catchment for given catchment (and adds the given to the list of subs in the larger)
 * - removes subcatchment from previous larger ID if existing
 * @param curr_pos position of catchment whose larger will be set
 * @param larger_id ID of larger catchment, can be empty to remove the connection
 */
void bil_system::set_larger_id(unsigned curr_pos, string larger_id)
{
  bilan *larger_pcatch;
  if (!larger_id.empty()) {
    larger_pcatch = get_pcatch_by_id(larger_id);
    if (curr_pos >= get_catch_count(false) || larger_pcatch == 0)
      throw bil_err("Required catchment of larger catchment does not exist in the system.");
  }

  bilan *curr_pcatch = get_pcatch(curr_pos);
  string prev_larger_id = curr_pcatch->get_larger_id();
  if (!prev_larger_id.empty()) //remove previous larger ID
    get_pcatch_by_id(prev_larger_id)->remove_sub(curr_pcatch->get_id());
  curr_pcatch->set_larger_id(larger_id);
  if (!larger_id.empty())
    larger_pcatch->add_sub(curr_pcatch->get_id());
}

/**
 * - sets ID of larger catchment for given catchment (and adds the given to the list of subs in the larger)
 * @param curr_pos position of catchment whose larger will be set
 * @param larger_pos position of larger catchment
 */
void bil_system::set_larger_id(unsigned curr_pos, unsigned larger_pos)
{
  set_larger_id(curr_pos, get_pcatch(larger_pos)->get_id());
}

/**
 * - makes changes (catchment count and IDs and removes optimization results) after catchment is added to the system
 * @param pos position to that the new catchment will be added
 * @param clear_opt whether system optimization list should be cleared when adding
 */
void bil_system::finish_adding(unsigned pos, bool clear_opt)
{
  catch_count++;
  assign_id(pos);
  if (clear_opt) {
    catchs_opt.clear();
    catch_opt_count = 0;
  }
}

/**
 * - adds a catchment to the system as the last element and assigns an ID to it
 * @param bil catchment as a Bilan instance
 */
void bil_system::add_catchment(bilan *bil)
{
  catchs.push_back(*bil);
  finish_adding(catch_count, true);
}

/**
 * - adds a catchment to the system to the given position and assigns an ID to it
 * - appends to the end if cat_n equals to the number of catchments
 * @param bil catchment as a Bilan instance
 * @param cat_n serial number of catchment to that the new catchment will be added
 * @param clear_opt whether system optimization list should be cleared when adding
 */
void bil_system::add_catchment(bilan *bil, unsigned cat_n, bool clear_opt)
{
  if (cat_n > get_catch_count(false))
    throw bil_err("Required position does not exist in the system.");

  list<bilan>::iterator ci = catchs.begin();
  advance(ci, cat_n);
  catchs.insert(ci, *bil);
  finish_adding(cat_n, clear_opt);
}

/**
 * - removes a catchment from the system
 * - removes also its relations to other catchments
 * @param cat_n serial number of required catchment
 */
void bil_system::remove_catchment(unsigned cat_n)
{
  if (cat_n >= get_catch_count(false))
    throw bil_err("Required catchment does not exist in the system.");

  //optimization results are not valid anymore
  catchs_opt.clear();
  catch_opt_count = 0;

  //remove from larger catchment and subcatchments
  bilan *pcatch = get_pcatch(cat_n);
  string curr_id = pcatch->get_id();
  string larger_id = pcatch->get_larger_id();
  if (!larger_id.empty()) {
    get_pcatch_by_id(larger_id)->remove_sub(curr_id);
  }
  if (pcatch->sub_count() > 0) {
    list<string> &sub_ids = pcatch->get_sub_ids();
    for (list<string>::iterator idi = sub_ids.begin(); idi != sub_ids.end(); ++idi) {
      get_pcatch_by_id(*idi)->set_larger_id("");
    }
  }
  list<bilan>::iterator ci = catchs.begin();
  advance(ci, cat_n);
  catchs.erase(ci);
  catch_count--;
}

/**
 * - gets number of catchment in the system
 * @param only_opt whether to get number of optimized catchments only
 * @return number of catchments
 */
unsigned bil_system::get_catch_count(bool only_opt)
{
  if (only_opt)
    return catch_opt_count;
  else
    return catch_count;
}

/**
 * - gets catchment from list of all catchments by index - inefficient
 * @param cat_n serial number of required catchment
 * @return model for the required catchment
 */
bilan bil_system::get_catch(unsigned cat_n)
{
  return *(get_pcatch(cat_n));
}

/**
 * - gets pointer to bilan instance from list of all catchments by index - inefficient
 * @param cat_n serial number of required catchment
 * @return pointer to bilan for the required catchment
 */
bilan* bil_system::get_pcatch(unsigned cat_n)
{
  if (cat_n >= get_catch_count(false))
    throw bil_err("Required catchment does not exist in the system.");

  list<bilan>::iterator ci = catchs.begin();
  advance(ci, cat_n);
  return &(*ci);
}

/**
 * - gets pointer to bilan instance from list of all catchments by catchment ID - inefficient
 * @param cat_id ID of required catchment
 * @return pointer to bilan for the required catchment, zero if the system does not include given catchment
 */
bilan* bil_system::get_pcatch_by_id(string cat_id)
{
  for (list<bilan>::iterator ci = catchs.begin(); ci != catchs.end(); ++ci) {
    if (ci->get_id() == cat_id)
      return &(*ci);
  }
  return 0;
}

/**
 * - gets position (index) in the system for catchment with given ID
 * @param cat_id ID of required catchment
 * @return pointer position in the system, -1 if the system does not include given catchment
 */
int bil_system::get_pos_by_id(string cat_id)
{
  int pos = 0;
  for (list<bilan>::iterator ci = catchs.begin(); ci != catchs.end(); ++ci) {
    if (ci->get_id() == cat_id)
      return pos;
    pos++;
  }
  return -1;
}

/**
 * - sets catchment from list of all catchments by index - inefficient
 * @param cat_n serial number of required catchment
 * @param bil model to replace that one at given position
 */
void bil_system::set_catch(unsigned cat_n, bilan *bil)
{
  if (cat_n >= get_catch_count(false))
    throw bil_err("Required catchment does not exist in the system.");

  list<bilan>::iterator ci = catchs.begin();
  advance(ci, cat_n);
  *ci = *bil;
}

/**
 * - gets optimized catchment
 * @param cat_n serial number of required catchment
 * @return model for the required catchment
 */
bilan bil_system::get_catch_opt(unsigned cat_n)
{
  return *(get_pcatch_opt(cat_n));
}

/**
 * - gets pointer to optimized catchment
 * @param cat_n serial number of required catchment
 * @return pointer to bilan for the required catchment
 */
bilan* bil_system::get_pcatch_opt(unsigned cat_n)
{
  if (cat_n >= get_catch_count(true))
    throw bil_err("Required catchment does not exist in the system.");

  return catchs_opt[cat_n];
}

/**
 * - changes optimization type
 * - no change if new type equals to the current
 * @param new_type new optimization type
 */
void bil_system::change_optim_type(optimizer_gen<bilsys_fcd*>::optim_type new_type)
{
  if (new_type != optim->get_type()) {
    delete optim;
    switch (new_type) {
      case optimizer_gen<bilsys_fcd*>::BS:
        optim = new optimizer<bilsys_fcd*>();
        optim->set_functoid(&fcd);
        break;
      case optimizer_gen<bilsys_fcd*>::DE:
        optim = new DE_optim<bilsys_fcd*>();
        optim->set_functoid(&fcd);
        break;
      default:
        throw bil_err("Unknown optimization type.");
        break;
    }
  }
}

/**
 * - calculates PET estimation for all catchments by method stored as their attribute pet_type
 */
void bil_system::calc_pet()
{
  for (list<bilan>::iterator ci = catchs.begin(); ci != catchs.end(); ++ci)
    ci->calc_pet();
}

/**
 * - finds recursively the top catchment within the system for the given catchment
 * - throws an error if a cycle is found
 * @param bil catchment whose top catchment will be found
 * @param found_ids list of IDs that have been found so far - larger catchment as one of them means there is a cycle
 */
string bil_system::find_top_id(bilan *bil, list<string> &found_ids)
{
  string curr_larger_id = bil->get_larger_id();
  for (list<string>::iterator fi = found_ids.begin(); fi != found_ids.end(); ++fi) {
    if (curr_larger_id == *fi)
      throw bil_err("There is a cycle in the system of catchments. The system cannot be calculated.");
  }
  if (curr_larger_id.empty())
    return bil->get_id();
  else {
    found_ids.push_back(curr_larger_id);
    return find_top_id(get_pcatch_by_id(curr_larger_id), found_ids);
  }
}

/**
 * - finds ID of larger catchment considering only catchments for optimization
 * @param cat_id catchment ID whose larger catchment is to be found
 */
string bil_system::find_larger_id_optim(string cat_id)
{
  string tmp_larger_id = get_pcatch_by_id(cat_id)->get_larger_id();
  if (tmp_larger_id.empty() || get_pcatch_by_id(tmp_larger_id)->get_system_optim())
    return tmp_larger_id;
  else
    return find_larger_id_optim(tmp_larger_id);
}

/**
 * - prepares one set of parameters from all catchments
 * - checks if catchments have the same type
 * - checks if areas of catchments are set, otherwise catchment is rejected
 * - checks if catchments are connected with other catchments and do not form a cycle
 * - finds out common time period for catchments and their larger catchments
 * - intended to be called immediately before optimization (only its setting can follow)
 */
void bil_system::prepare_opt()
{
  list<bilan>::iterator ci;
  bilan::bilan_type tmp_type = bilan::MONTHLY;
  unsigned tmp_c = 1, tmp_catch_opt_count = 0;
  bool first_area_found = false; //first catchment with area is used as reference
  for (ci = catchs.begin(); ci != catchs.end(); ++ci) {
    if (ci->has_area()) {
      if (!first_area_found) {
          tmp_type = ci->get_type();
          ci->set_system_optim(true);
          tmp_catch_opt_count++;
          //number of parameters from the first catchment (must be same for all catchments)
          par_count_catch = ci->par_count;
          par_fix_count_catch = ci->par_fix_count;
          first_area_found = true;
      }
      else if (ci->get_type() != tmp_type)
        BIL_OSTREAM << "Catchment " << tmp_c << " has different model type and will not be used for optimization.\n";
      else {
        ci->set_system_optim(true);
        tmp_catch_opt_count++;
      }
    }
    else
      BIL_OSTREAM << "Catchment " << tmp_c << " will not be used for optimization because its area has not been set.\n";
    tmp_c++;
  }

  //check of catchment connections and cycles
  string top_id, curr_top_id; //ID of top catchment - the top catchment for the first catchment is used
  bool is_top_id = false;
  tmp_c = 1;
  for (ci = catchs.begin(); ci != catchs.end(); ++ci) {
    if (ci->get_system_optim()) {
      list<string> tmp_found_ids;
      tmp_found_ids.push_back(ci->get_id());
      curr_top_id = find_top_id(&(*ci), tmp_found_ids);
      if (curr_top_id.empty())
        curr_top_id = ci->get_id(); //empty larger_id for current
      if (!is_top_id) {
        top_id = curr_top_id;
        is_top_id = true;
      }
      if (curr_top_id != top_id) {
        BIL_OSTREAM << "Catchment " << tmp_c << " will not be used for optimization because it is not connected to the system with the first catchment.\n";
        ci->set_system_optim(false);
        tmp_catch_opt_count--;
      }
      else { //check if the larger catchment is really larger
        string tmp_larger_id = ci->get_larger_id();
        if (!tmp_larger_id.empty()) {
          if (ci->get_area() > get_pcatch_by_id(tmp_larger_id)->get_area())
            BIL_OSTREAM << "Catchment '" << ci->input_file << "' is actually larger than the catchment set as larger for it.\n";
        }
      }
    }
    tmp_c++;
  }
  catch_opt_count = tmp_catch_opt_count;

  //catchments for optimization to temporary vector (due to access to parameters)
  catchs_opt.resize(catch_opt_count);
  tmp_c = 0;
  for (ci = catchs.begin(); ci != catchs.end(); ++ci) {
    if (ci->get_system_optim()) {
      ci->set_larger_id_optim(find_larger_id_optim(ci->get_id()));
      catchs_opt[tmp_c] = &(*ci);
      tmp_c++;
    }
  }
  //calculate number of common time steps and the first time step for catchments and their larger catchments
  //to be used for calculation of the weighted penalty for the system
  common_begin.clear();
  common_begin_larger.clear();
  common_ts.clear();
  common_ts_sum = 0;
  for (unsigned cat = 0; cat < get_catch_count(true); cat++) {
    bilan *curr_cat = catchs_opt[cat];
    date curr_init_date, curr_last_date, larger_init_date, larger_last_date;
    if (!curr_cat->get_larger_id_optim().empty()) {
      bilan *larger_cat = get_pcatch_by_id(curr_cat->get_larger_id_optim());

      curr_init_date = curr_cat->get_init_date();
      curr_last_date = curr_cat->get_last_date();

      larger_init_date = larger_cat->get_init_date();
      larger_last_date = larger_cat->get_last_date();

      unsigned tmp_begin, tmp_begin_larger, tmp_ts;
      tmp_begin = tmp_begin_larger = tmp_ts = 0;
      if (!(curr_last_date < larger_init_date || curr_init_date > larger_last_date)) {
        unsigned ts;
        date begin_date = curr_init_date > larger_init_date ? curr_init_date : larger_init_date;
        date end_date = curr_last_date > larger_last_date ? larger_last_date : curr_last_date;
        for (ts = 0; ts < curr_cat->time_steps; ts++) {
          if (curr_cat->calen[ts] == begin_date) {
            tmp_begin = ts;
          }
          if (curr_cat->calen[ts] == end_date) {
            tmp_ts = ts - tmp_begin + 1;
            break;
          }
        }
        for (ts = 0; ts < larger_cat->time_steps; ts++) {
          if (larger_cat->calen[ts] == begin_date) {
            tmp_begin_larger = ts;
            break;
          }
        }
      }
      common_begin.insert(pair<string, unsigned>(curr_cat->get_id(), tmp_begin));
      common_begin_larger.insert(pair<string, unsigned>(curr_cat->get_id(), tmp_begin_larger));
      common_ts.insert(pair<string, unsigned>(curr_cat->get_id(), tmp_ts));
      common_ts_sum += tmp_ts;
    }
  }
}

/**
 * - runs the previously set optimization algorithm for the system
 */
void bil_system::optimize()
{
  if (catch_opt_count == 0)
    throw bil_err("System contains no catchment.");
  optim->optimize();
}

/**
 * - calculates sum of weights for catchments to be optimized
 */
void bil_system::calc_sum_weights()
{
  for (unsigned cat = 0; cat < catch_opt_count; cat++) {
    catchs_opt[cat]->sum_weights = catchs_opt[cat]->get_var_sum(bilan::WEI);
  }
}

/**
 * - checks if input variables needed for optimization are loaded for all catchments
 * @param is_weight_BF whether baseflow will be used for optimization
 */
void bil_system::check_vars_for_optim(bool is_weight_BF)
{
  for (unsigned cat = 0; cat < catch_opt_count; cat++) {
    catchs_opt[cat]->check_vars_for_optim(is_weight_BF);
  }
}

/**
 * - gets value of parameter
 * @param par_n parameter serial number within all catchments
 * @param par_type type of parameter
 * @return value of parameter
 */
double bil_system::get_param(unsigned par_n, optimizer_gen<bilsys_fcd*>::param_type par_type)
{
  unsigned catch_n = par_n / par_count_catch; //division of integer to get integer
  unsigned par_catch_n = par_n % par_count_catch;
  switch (par_type) {
    case parameter::INIT:
      return catchs_opt[catch_n]->param[par_catch_n].initial;
    case parameter::CURR:
      return catchs_opt[catch_n]->param[par_catch_n].value;
    case parameter::LOWER:
      return catchs_opt[catch_n]->param[par_catch_n].lower;
    case parameter::UPPER:
      return catchs_opt[catch_n]->param[par_catch_n].upper;
    default:
      throw bil_err("Undefined parameter type.");
      break;
  }
}

/**
 * - sets value of parameter
 * @param par_n parameter serial number within all catchments
 * @param par_type type of parameter
 * @param value value to be set
 */
void bil_system::set_param(unsigned par_n, optimizer_gen<bilsys_fcd*>::param_type par_type, double value)
{
  unsigned catch_n = par_n / par_count_catch;
  unsigned par_catch_n = par_n % par_count_catch;
  switch (par_type) {
    case parameter::INIT:
      catchs_opt[catch_n]->param[par_catch_n].initial = value;
      break;
    case parameter::CURR:
      catchs_opt[catch_n]->param[par_catch_n].value = value;
      break;
    case parameter::LOWER:
      catchs_opt[catch_n]->param[par_catch_n].lower = value;
      break;
    case parameter::UPPER:
      catchs_opt[catch_n]->param[par_catch_n].upper = value;
      break;
    default:
      break;
  }
}

/**
 * - gets number of parameters from all catchments
 * @return number of parameters
 */
unsigned bil_system::get_param_count()
{
  return par_count_catch * catch_opt_count;
}

/**
 * - gets number of fixed parameters from all catchments
 * @return number of fixed parameters
 */
unsigned bil_system::get_param_fix_count()
{
  return par_fix_count_catch * catch_opt_count;
}

/**
 * - gets parameter name
 * @param par_n parameter number
 */
std::string bil_system::get_param_name(unsigned par_n)
{
  return catchs_opt[0]->get_param_name(par_n % par_count_catch);
}

/**
 * - gets number of common time steps for given catchment and its larger catchment
 * @param cat_opt_n position in the list of optimized catchments
 * @return number of time steps
 */
unsigned bil_system::get_common_ts(unsigned cat_opt_n)
{
  string larger_id = catchs_opt[cat_opt_n]->get_larger_id_optim();
  if (!larger_id.empty())
    return common_ts[catchs_opt[cat_opt_n]->get_id()];
  else
    return 0;
}

/**
 * - runs the model for all catchments
 * @param init_GS initial groundwater storage, same for each catchment
 */
void bil_system::run(long double init_GS)
{
  for (unsigned cat = 0; cat < catch_opt_count; cat++) {
    catchs_opt[cat]->run(init_GS);
  }
}

/**
 * - calculates value of penalty for given optimized catchment and its larger catchment
 * @param cat_opt_n position in the list of optimized catchments
 * @param pen penalty type
 * @return penalty value
 */
long double bil_system::calc_penalty(unsigned cat_opt_n, unsigned pen)
{
  (void) pen; //TDD
  string larger_id = catchs_opt[cat_opt_n]->get_larger_id_optim();
  string id = catchs_opt[cat_opt_n]->get_id();
  if (!larger_id.empty()) {
    unsigned neg_flows = 0;
    bilan *larger_bil = get_pcatch_by_id(larger_id);
    unsigned ts_larger = common_begin_larger[id];
    for (unsigned ts = common_begin[id]; ts < common_begin[id] + common_ts[id]; ts++) {
      if (larger_bil->convert_value_var(ts_larger, bilan::RM, bilan::MM, bilan::M3S1, bilan::SERIES)
        - catchs_opt[cat_opt_n]->convert_value_var(ts, bilan::RM, bilan::MM, bilan::M3S1, bilan::SERIES) < 0) {
        neg_flows++;
      }
      ts_larger++;
    }
    return 0.1 * neg_flows;
  }
  else
    return 0;
}

/**
 * - calculates optimization criterion value for a system
 * - resulting criterion as mean of criteria for each catchments
 * - and penalty is added for negative difference in flows between a current and larger catchment
 * @param crit criterion type
 * @param pen penalty type
 * @param weight_BF weight for baseflow
 * @param use_weights whether to use weights
 * @return criterion value
 */
long double bil_system::calc_crit(unsigned crit, unsigned pen, double weight_BF, bool use_weights)
{
  long double tmp_crit = 0;
  for (unsigned cat = 0; cat < catch_opt_count; cat++) {
    bilan *curr_cat = catchs_opt[cat];
    tmp_crit += curr_cat->calc_crit_RM_BF(crit, weight_BF, use_weights);
    if (!curr_cat->get_larger_id_optim().empty()) {
      tmp_crit += calc_penalty(cat, pen); //TDD weight for penalty when a relative criterion will be implemented
    }
  }
  return tmp_crit / static_cast<long double>(catch_opt_count);
}

/**
 * - calculates sum of weights for optimization
 */
void bilsys_fcd::calc_sum_weights()
{
  psbil->calc_sum_weights();
}

/**
 * - checks if input variables needed for optimization are loaded
 * @param is_weight_BF whether baseflow will be used for optimization
 */
void bilsys_fcd::check_vars_for_optim(bool is_weight_BF)
{
  psbil->check_vars_for_optim(is_weight_BF);
}

/**
 * - gets value of parameter
 * @param par_n parameter serial number
 * @param par_type type of parameter
 * @return value of parameter
 */
double bilsys_fcd::get_param(unsigned par_n, optimizer_gen<bilsys_fcd*>::param_type par_type)
{
  return psbil->get_param(par_n, par_type);
}

/**
 * - sets value of parameter
 * @param par_n parameter serial number
 * @param par_type type of parameter
 * @param value value to be set
 */
void bilsys_fcd::set_param(unsigned par_n, optimizer_gen<bilsys_fcd*>::param_type par_type, double value)
{
  psbil->set_param(par_n, par_type, value);
}

/**
 * - gets number of parameters from all catchments
 * @return number of parameters
 */
unsigned bilsys_fcd::get_param_count()
{
  return psbil->get_param_count();
}

/**
 * - gets number of fixed parameters from all catchments
 * @return number of fixed parameters
 */
unsigned bilsys_fcd::get_param_fix_count()
{
  return psbil->get_param_fix_count();
}

/**
 * - gets parameter name
 * @param par_n parameter number
 */
std::string bilsys_fcd::get_param_name(unsigned par_n)
{
  return psbil->get_param_name(par_n);
}

/**
 * - gets number of catchments to be optimized
 * @return number of catchments
 */
unsigned bilsys_fcd::get_catch_count()
{
  return psbil->get_catch_count(true);
}

/**
 * - runs the model for all catchments
 * @param init_GS initial groundwater storage, same for each catchment
 */
void bilsys_fcd::run(long double init_GS)
{
  psbil->run(init_GS);
}

/**
 * - calculates optimization criterion value for a system of catchments
 * @param crit criterion type
 * @param pen penalty type
 * @param weight_BF weight for baseflow
 * @param use_weights whether to use weights
 * @return criterion value
 */
long double bilsys_fcd::calc_crit(unsigned crit, unsigned pen, double weight_BF, bool use_weights)
{
  return psbil->calc_crit(crit, pen, weight_BF, use_weights);
}
